This folder contains all the data we have from the most recent experiment. Starting from San Diego to Maryland to South Calorina to Geogia to Portland and then back to San Diego.

In the data, there are mainly three providers which are AT&T T-mobile and Verizon, and the ipv4 scamper results are in \*\_wartsv4\_\* folders while the ipv6 scamper results are in \*\_wartsv6\_\* folders. We have ipv6 results for T-mobile and Verizon but not AT&T is because we use AT&T pre-paid plan which does not have ipv6 address. 

For IPv6 results from San Diego to Maryland (i.e. the data in "second_SD_MD_raw" folder) all the first three hops in T-mobile results and first five hops in Verizon results are stars (i.e. "\*"). This is not because these hops never reply to us but because I asked the scamper to jump thesee hops to avoid "loop problem". Latter during the trip from Maryland to Geogia to Portland to San Diego, I fixed this problem and you would be able to see the first few hops in T-mobile and Verizon in the data in . You would still see the hop 2 to 5 are still stars, but yes, that's because these hops never respond to us.

The location information of each experiment is in \*\_OUTPUT\_\* folder, you would see the CellID, TAC, MNC and MMC in the cellinfo.

For the rest of the folders, \*\_google\_warts\_\* and \*\_Netflix\_warts\_\* contains the traceroute results to google and Netflix CDN. \*
\_sysinfo\_\* contains the traceroute results to CAIDA server.